import sys
import GPy

__version__ = '0.8.1'

def hellopythonsnap():
    print("hello python snap")
    sys.exit(0)
    
if __name__ == "__main__":
    hellopythonsnap()
